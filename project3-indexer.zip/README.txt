Team Name - Patriots
Ankush Verma 904435669
Saransh Gupta 104433358
Grace Days Used: 1

We have build Lucene's inverted index on the itemId, item name, category and description fields using the standardAnalyzer of the library. Thereby, we are able to search over the union of the these attributes.Please note that we have discussed certain implementation details with Miraj Shah and Puneet Singh Ahluwalia
