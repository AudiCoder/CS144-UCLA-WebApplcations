Team Name - Patriots
Ankush Verma 904435669
Saransh Gupta 104433358
Grace Days Used: 1

The Searcher is used to support keyword search using the lucene index and region based queries using the sql spatial indexing (using R-trees).Please note that we have discussed certain implementation details with Miraj Shah and Puneet Singh Ahluwalia